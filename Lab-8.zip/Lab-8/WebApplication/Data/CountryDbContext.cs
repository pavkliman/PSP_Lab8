﻿using Microsoft.EntityFrameworkCore;
using WebApplication.Models;

namespace WebApplication.Data
{
    public class CountryDbContext : DbContext
    {
        public CountryDbContext(DbContextOptions<CountryDbContext> options)
            : base(options) 
        {
            Database.EnsureCreated();
        }

        public DbSet<Country> Countries { get; set; }
    }
}
