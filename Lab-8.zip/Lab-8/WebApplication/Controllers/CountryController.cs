﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Data;
using WebApplication.Models;

namespace WebApplication.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Produces("application/json")]
    public class CountryController : ControllerBase
    {
        private readonly CountryDbContext _db;

        public CountryController(CountryDbContext db)
        {
            _db = db;
            if (!_db.Countries.Any())
            {
                var country = new Country
                {
                    Name = "Belarus",
                    Continent = "Europe",
                    GovermentForm = "Presidential republic",
                    Area = 206700,
                };
                _db.Countries.Add(country);

                country = new Country
                {
                    Name = "Some country",
                    Continent = "Some continent",
                    GovermentForm = "Some goverment form",
                    Area = 100000,
                };
                _db.Countries.Add(country);

                _db.SaveChanges();
            }
        }

        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<Country>), StatusCodes.Status200OK)]
        public IActionResult GetCountries()
        {
            return Ok(_db.Countries);
        }

        [HttpGet("{id}")]
        [ProducesResponseType(typeof(Country), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetCountriyById(int id)
        {
            var countryById = await _db.Countries.FindAsync(id);
            return countryById is null ? NotFound() : Ok(countryById);
        }

        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> CreateCountry([FromBody] Country country)
        {
            await _db.Countries.AddAsync(country);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCountriyById), new { id = country.Id }, country);
        }

        [HttpPut]
        [ProducesResponseType(typeof(Country), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateCountry([FromBody] Country country)
        {
            var countryById = await _db.Countries.FindAsync(country.Id);
            if (countryById == null)
            {
                return NotFound();
            }

            countryById.Name = country.Name;
            countryById.GovermentForm = country.GovermentForm;
            countryById.Continent = country.Continent;
            countryById.Area = country.Area;

            _db.Countries.Update(countryById);
            await _db.SaveChangesAsync();

            return Ok(countryById);
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(typeof(Country) ,StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<IActionResult> DeleteCountry(int id)
        {
            var countryById = await _db.Countries.FindAsync(id);
            if (countryById == null)
            {
                return NotFound();
            }

            _db.Countries.Remove(countryById);
            await _db.SaveChangesAsync();

            return Ok(countryById);
        }
    }
}
